# manjaro-zsh-config

Manjaro Zsh configuration for Manjaro and other Arch-based systems.

## Install

Place the `.zshrc` you want to distribute in this directory, then run:

```sh
./install.sh
```

The script runs `makepkg -si` in this order:

1. `ttf-meslo-nerd-font-powerlevel10k`
2. `zsh-theme-powerlevel10k`
3. `manjaro-zsh-config`

The final package installs `.zshrc` to `/etc/skel/.zshrc` for new users.
