#!/usr/bin/env bash

set -euo pipefail

readonly script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
readonly zshrc_source="$script_dir/.zshrc"
readonly packages_dir="$script_dir/packages"

if [[ "${EUID}" -eq 0 ]]; then
  printf 'Error: do not run this script as root; makepkg must run as a regular user.\n' >&2
  exit 1
fi

if [[ ! -f "$zshrc_source" ]]; then
  printf 'Error: expected .zshrc at %s\n' "$zshrc_source" >&2
  exit 1
fi

build_and_install() {
  local package_name="$1"
  local package_dir="$packages_dir/$package_name"

  printf 'Building and installing %s...\n' "$package_name"
  cp "$zshrc_source" "$package_dir/.zshrc"
  trap 'rm -f "$package_dir/.zshrc"' RETURN
  (
    cd "$package_dir"
    makepkg -si --noconfirm
  )
}

build_and_install ttf-meslo-nerd-font-powerlevel10k
build_and_install zsh-theme-powerlevel10k
build_and_install manjaro-zsh-config
